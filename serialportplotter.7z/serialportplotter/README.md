# serialportplotter

One more serial plotter
just have to print $&lt;value&gt;;\r\n on the serial line to have it graphed
